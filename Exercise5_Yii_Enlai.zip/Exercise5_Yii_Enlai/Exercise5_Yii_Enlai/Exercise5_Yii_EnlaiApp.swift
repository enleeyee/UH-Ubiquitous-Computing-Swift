//
//  Exercise5_Yii_EnlaiApp.swift
//  Exercise5_Yii_Enlai
//
//  Created by Enlai Yii on 10/8/24.
//

import SwiftUI

@main
struct Exercise5_Yii_EnlaiApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}
