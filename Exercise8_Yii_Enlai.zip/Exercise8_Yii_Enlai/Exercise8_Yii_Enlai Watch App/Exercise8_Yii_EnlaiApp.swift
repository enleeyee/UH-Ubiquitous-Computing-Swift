//
//  Exercise8_Yii_EnlaiApp.swift
//  Exercise8_Yii_Enlai Watch App
//
//  Created by Enlai Yii on 11/8/24.
//

import SwiftUI

@main
struct Exercise8_Yii_Enlai_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
