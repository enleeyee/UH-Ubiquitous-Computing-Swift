//
//  Exercise2_Yii_EnlaiApp.swift
//  Exercise2_Yii_Enlai
//
//  Created by Enlai Yii on 8/29/24.
//

import SwiftUI

@main
struct Exercise2_Yii_EnlaiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
