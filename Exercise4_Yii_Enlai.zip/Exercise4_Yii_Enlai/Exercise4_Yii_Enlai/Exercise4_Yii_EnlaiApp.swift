//
//  Exercise4_Yii_EnlaiApp.swift
//  Exercise4_Yii_Enlai
//
//  Created by Enlai Yii on 9/16/24.
//

import SwiftUI

@main
struct Exercise4_Yii_EnlaiApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}
