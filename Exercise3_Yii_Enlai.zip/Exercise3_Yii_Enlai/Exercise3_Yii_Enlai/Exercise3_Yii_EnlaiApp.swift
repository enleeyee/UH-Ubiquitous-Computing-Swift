//
//  Exercise3_Yii_EnlaiApp.swift
//  Exercise3_Yii_Enlai
//
//  Created by Enlai Yii on 9/11/24.
//

import SwiftUI

@main
struct Exercise3_Yii_EnlaiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
