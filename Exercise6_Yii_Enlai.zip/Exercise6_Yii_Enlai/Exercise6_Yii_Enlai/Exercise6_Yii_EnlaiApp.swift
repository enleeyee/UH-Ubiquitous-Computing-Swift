//
//  Exercise6_Yii_EnlaiApp.swift
//  Exercise6_Yii_Enlai
//
//  Created by Enlai Yii on 10/11/24.
//

import SwiftUI

@main
struct Exercise6_Yii_EnlaiApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}
