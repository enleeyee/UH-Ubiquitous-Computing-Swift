//
//  Exam2_Yii_EnlaiApp.swift
//  Exam2_Yii_Enlai
//
//  Created by Enlai Yii on 10/17/24.
//

import SwiftUI

@main
struct Exam2_Yii_EnlaiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
