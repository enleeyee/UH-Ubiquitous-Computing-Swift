//
//  Exam1_Yii_EnlaiApp.swift
//  Exam1_Yii_Enlai
//
//  Created by Enlai Yii on 9/19/24.
//

import SwiftUI

@main
struct Exam1_Yii_EnlaiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
